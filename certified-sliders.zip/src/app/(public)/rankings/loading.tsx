export default function Loading() {
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="animate-pulse text-sm text-muted-foreground">Loading rankings…</div>
    </div>
  );
}
