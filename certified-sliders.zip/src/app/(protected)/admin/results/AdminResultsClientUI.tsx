// src/app/(protected)/admin/results/AdminResultsClientUI.tsx
"use client";

import { Toaster } from "sonner";

export default function AdminResultsClientUI() {
    return <Toaster richColors closeButton />;
}