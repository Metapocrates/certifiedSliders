export default function AthletesIndex() {
  return (
    <main className="container mx-auto max-w-3xl p-6">
      <h1 className="text-2xl font-semibold">Find athletes</h1>
      <p className="mt-2 text-sm opacity-70">Search coming soon.</p>
    </main>
  );
}
